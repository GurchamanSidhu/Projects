﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Framework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PlayGroundEntities1 obj = new PlayGroundEntities1();
            var va = obj.Employees;

            var context = new PlayGroundEntities1();
            var employee = new Employee
            {
                EmpName = "Sandy",
                Gender = "Female",
                DOB = DateTime.Now,
            };

            // To save datas
            //context.Employees.Add(employee);
            //context.SaveChanges();

            // To select data
            using (var context2 = new PlayGroundEntities1())
            {
                var v = (from name in context2.Employees
                         select name).ToList();

                var aa = v.ElementAt(0).EmpNo;
            }

            // Using query
            using (var ctx = new PlayGroundEntities1())
            {
                var employeeList = ctx.Employees
                                    .SqlQuery("Select * from Employee WHERE EmpNo = 4")
                                    .ToList<Employee>();
            }

            // Using query, parameterised
            using (var ctx = new PlayGroundEntities1())
            {
                var employeeList = ctx.Employees
                                    .SqlQuery("Select * from Employee WHERE EmpNo = @id", new SqlParameter("@id", 1))
                                    .ToList<Employee>();
            }


            // Using standard query
            using (var ctx = new PlayGroundEntities1())
            {
                var var1 = ctx.Database.SqlQuery<string>("SELECT EmpName FROM Employee A \r\nINNER JOIN EmployeeAddress B ON A.Empno = B.EmpNo").ToList();


                //or
                var var2 = ctx.Database.SqlQuery<Employee>("Select * from Employee where EmpNo=@id", new SqlParameter("@id", 1))
                                        .ToList();
            }

            // Insert Update Query
            using (var ctx = new PlayGroundEntities1())
            {
                int noOfRowUpdated = ctx.Database.ExecuteSqlCommand("Update employee set flgActive = 0 where EmpNo = 1");

                int noOfRowInserted = ctx.Database.ExecuteSqlCommand("INSERT INTO Employee VALUES ('XYZ','Female','85000','1 jan 2004',1)");

                int noOfRowDeleted = ctx.Database.ExecuteSqlCommand("delete from employee where EmpNo = 10");
            }

            // Stored Proc
            using (var ctx = new PlayGroundEntities1())
            {
                var data = ctx.usp_GetEmpDetails(1);
            }

            // Or Stored Proc
            using (var contextSp = new PlayGroundEntities1())
            {
                var EmpNoParameter = new SqlParameter("@EmpNo", 4);

                var result = contextSp.Database
                    .SqlQuery<Employee>("usp_GetEmpDetails @EmpNo", EmpNoParameter)
                    .ToList();

                // With multiple parameters
                object[] xparams = {
            new SqlParameter("@ParameterWithNumvalue", DBNull.Value),
            new SqlParameter("@In_Parameter", "Value"),
            new SqlParameter("@Out_Parameter", SqlDbType.Int) {Direction = ParameterDirection.Output}};

                contextSp.Database.ExecuteSqlCommand("exec StoredProcedure_Name @ParameterWithNumvalue, @In_Parameter, @Out_Parameter", xparams);
                var ReturnValue = ((SqlParameter)xparams[2]).Value;

            }
        }
    }
}
