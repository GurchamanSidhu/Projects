﻿using Dalc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;

namespace ComsoleApp_Core
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // Step 1 - Add service collection
            // Add Nuget packages
            ServiceCollection serviceCollection = new ServiceCollection();


            // Step 2 Build ServiceCollection
            IConfiguration configuration = new ConfigurationBuilder()
                       .SetBasePath(Directory.GetParent(AppContext.BaseDirectory).FullName)            // Include System.IO for Directory
                       .AddJsonFile("appsettings.json")
                       .Build();

            // Add the configuration to serviceCollection
            serviceCollection.AddSingleton<IConfiguration>(configuration);

            serviceCollection.AddSingleton<Database>();

            // For testing
            var serviceprovider = serviceCollection.BuildServiceProvider();
            var testInstance = serviceprovider.GetService<Database>();
            testInstance.TestMethod();
        }
    }
}
