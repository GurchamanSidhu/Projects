﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Dalc.Repository.Models;
using Microsoft.Extensions.Configuration;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Dalc.Repository
{
    public partial class PlayGroundDbContext : DbContext
    {
        public readonly IConfiguration configuration;

        public PlayGroundDbContext(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public PlayGroundDbContext(DbContextOptions<PlayGroundDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<EmployeeAddress> EmployeeAddress { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseSqlServer("Data Source=SIDHU;Initial Catalog=PlayGround;Integrated Security=True");
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("PlayGroundDB"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.EmpNo)
                    .HasName("PK__Employee__AF2D66D376A2679A");

                entity.Property(e => e.EmpName).IsUnicode(false);

                entity.Property(e => e.Gender).IsUnicode(false);
            });

            modelBuilder.Entity<EmployeeAddress>(entity =>
            {
                entity.HasKey(e => e.IntSl)
                    .HasName("PK__Employee__11A9D3B9FEA1E42A");

                entity.Property(e => e.Address1).IsUnicode(false);

                entity.Property(e => e.Address2).IsUnicode(false);

                entity.Property(e => e.City).IsUnicode(false);

                entity.Property(e => e.Country).IsUnicode(false);

                entity.Property(e => e.Pin).IsUnicode(false);

                entity.HasOne(d => d.EmpNoNavigation)
                    .WithMany(p => p.EmployeeAddress)
                    .HasForeignKey(d => d.EmpNo)
                    .HasConstraintName("FK__EmployeeA__EmpNo__2B3F6F97");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
