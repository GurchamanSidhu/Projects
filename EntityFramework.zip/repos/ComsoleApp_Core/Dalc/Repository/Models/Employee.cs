﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Dalc.Repository.Models
{
    public partial class Employee
    {
        public Employee()
        {
            EmployeeAddress = new HashSet<EmployeeAddress>();
        }

        [Key]
        public int EmpNo { get; set; }
        [StringLength(100)]
        public string EmpName { get; set; }
        [StringLength(6)]
        public string Gender { get; set; }
        public double? Salary { get; set; }
        [Column("DOB", TypeName = "datetime")]
        public DateTime? Dob { get; set; }
        [Column("flgActive")]
        public bool? FlgActive { get; set; }

        [InverseProperty("EmpNoNavigation")]
        public virtual ICollection<EmployeeAddress> EmployeeAddress { get; set; }
    }
}
