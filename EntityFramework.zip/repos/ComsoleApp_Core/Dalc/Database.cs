﻿using Dalc.Repository;
using Dalc.Repository.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;

namespace Dalc
{
    public class Database
    {
        public readonly IConfiguration configuration;

        public Database(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public void TestMethod()
        {
            var dataFromJson = configuration.GetSection("Name").Value;
            var connection = configuration.GetConnectionString("PlayGroundDB");

            using (var context = new PlayGroundDbContext(configuration))
            {
                var Result = context.Employee.FromSqlRaw("SELECT * FROM Employee").ToList();
            }
        }
    }
}
