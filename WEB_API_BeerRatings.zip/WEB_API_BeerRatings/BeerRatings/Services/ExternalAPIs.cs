﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using BeerRatings.Models;

namespace BeerRatings.Services
{
    public class ExternalAPIs
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _cache;

        public ExternalAPIs(IConfiguration configuration, IMemoryCache memoryCache)
        {
            _configuration = configuration;
            _cache = memoryCache;
        }

        /// <summary>
        /// Gets Punk API data by beer name search 
        /// </summary>
        /// <param name="intID">ID of the beer</param>
        /// <returns>Data of the beer</returns>
        public async Task<IList<BeerDetailsModel>> GetBeerDetailsFromPunkAPIByID(int id)
        {
            IList<BeerDetailsModel> beerDetails = new List<BeerDetailsModel>();

            try
            {
                using (var httpClient = new HttpClient())
                {
                    using (var response = await httpClient.GetAsync((_configuration.GetSection("PunkAPIByID").Value) + Convert.ToString(id)))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();

                        if (!string.IsNullOrEmpty(apiResponse))
                        {
                            var result = JsonConvert.DeserializeObject(apiResponse);

                            // Punk API returns below JSON type in case Beer ID doesnot exist. If not found, will return empty objBeerDetails.

                            if (!result.ToString().Contains("No beer found that matches the ID",StringComparison.OrdinalIgnoreCase))
                                beerDetails = JsonConvert.DeserializeObject<IList<BeerDetailsModel>>(apiResponse);
                        }
                    }
                }

                return beerDetails;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;                   // Always use throw instead of 'throw ex'. throw provides good stack trace
            }
        }

        /// <summary>
        /// Gets Punk API data by Beer name search
        /// </summary>
        /// <param name="strBeerName">Beer Name</param>
        /// <returns>Data of the Beer</returns>
        public async Task<IList<BeerDetailsModel>> GetBeerDetailsFromPunkAPIByName(string beerName)
        {
            IList<BeerDetailsModel> beerDetails = new List<BeerDetailsModel>();
            IList<BeerDetailsModel> beerDetailsResult = new List<BeerDetailsModel>();
            bool ifAlreadyExists = false;

            try
            {
                // Just to demonstrate the concept of caching, caching the data for 30 seconds only. And even that is configurable in appsettings.json.

                ifAlreadyExists = _cache.TryGetValue("BeerDetails", out beerDetails);

                if (!ifAlreadyExists)
                {
                    using (var httpClient = new HttpClient())
                    {
                        using (var response = await httpClient.GetAsync((_configuration.GetSection("PunkAPI").Value)))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            beerDetails = JsonConvert.DeserializeObject<IList<BeerDetailsModel>>(apiResponse);
                        }
                    }

                    DateTimeOffset objDateTimeOffSet = new DateTimeOffset(DateTime.Now.AddSeconds(Convert.ToDouble(_configuration.GetSection("PunkAPICachingTime").Value)));
                    _cache.Set("BeerDetails", beerDetails, objDateTimeOffSet);
                }
                else
                {
                    beerDetails = (IList<BeerDetailsModel>)_cache.Get("BeerDetails");
                }


                foreach(BeerDetailsModel item in beerDetails)
                    if (item.name.Equals(beerName, StringComparison.OrdinalIgnoreCase))
                        beerDetailsResult.Add(item);

                return beerDetailsResult;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw;                   // Always use throw instead of 'throw ex'. throw provides good stack trace
            }

        }
    }
}
