﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Text.RegularExpressions;
using BeerRatings.Models;

namespace BeerRatings.Filters
{
    public class MyActionFilter : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {

        }

        public void OnActionExecuting(ActionExecutingContext actionContext)
        {
            try
            {
                // Taking UserRating details out of ActionArguments
                var UserRatings = (UserRatingsModel)actionContext.ActionArguments[Constants.UserRatings];

                Regex regex = new Regex(Constants.UserNameRegex);
                Match match = regex.Match(UserRatings.userName);

                // If User name is not in correct format
                if (!match.Success)
                    actionContext.Result = new BadRequestObjectResult(new JsonResult(new { Message = Messages.InValidUserName }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw new CustomException("Something went wrong. Please contact the API team.");  // Sending custom message
            }
        }
    }
}
